from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import base64

key = RSA.generate(2048)
public_key = key.publickey()
cipher = PKCS1_OAEP.new(public_key)

message = b"mensagem secreta"
ciphertext = cipher.encrypt(message)

# Descriptografar
cipher_dec = PKCS1_OAEP.new(key)
original = cipher_dec.decrypt(ciphertext)

print("Criptografado:", base64.b64encode(ciphertext))
print("Descriptografado:", original.decode())

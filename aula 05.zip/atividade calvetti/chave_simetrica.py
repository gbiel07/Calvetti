from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64

# Chave de 16 bytes (128 bits)
key = get_random_bytes(16)
cipher = AES.new(key, AES.MODE_EAX)

# Texto
text = b"mensagem secreta"
nonce = cipher.nonce
ciphertext, tag = cipher.encrypt_and_digest(text)

# Decodificando
cipher_dec = AES.new(key, AES.MODE_EAX, nonce=nonce)
original = cipher_dec.decrypt(ciphertext)

print("Criptografado:", base64.b64encode(ciphertext))
print("Descriptografado:", original.decode())

import hashlib

mensagem = "mensagem secreta"
hash = hashlib.sha256(mensagem.encode()).hexdigest()

print("Hash SHA-256:", hash)
